LAFAYETTE EIGHT-ZONE EDUCATIONAL TRAVEL DEMAND PILOT
Ahmad Hussain

Read the technical report for assumptions and full limitations.

Lafayette_OD_8x8_2023.csv: 2023 LODES internal primary-job relationships by residential origin and workplace destination, not observed peak-hour traffic.
Lafayette_Gravity_Predictions.csv: in-sample production-constrained gravity allocations. Compare against the observed O-D matrix; no independent validation is implied.
Lafayette_AM_Peak_Vehicle_OD.csv: illustrative AM vehicles/hour after assumed participation, peaking, and occupancy conversion.
Lesson6_Scenario_Summary.csv: low/baseline/high demand and assignment summaries.
Lafayette_Travel_Time_Matrix.csv: modeled network travel-time impedance, minutes.

External, nonwork, and routed intrazonal demand are omitted. These are not total observed roadway volumes. Model source execution and independent traffic-count validation have not been repeated for this portfolio.
